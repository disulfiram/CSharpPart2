﻿using System;

class Program
{
    static int ReadInts()       //Reads integers from console.
    {
        while (true)
        {
            int Integer;
            string Value = Console.ReadLine();
            bool Result = int.TryParse(Value, out Integer);
            if (Result == true)
            {
                return Integer;
            }
            else
            {
                Console.Write(@"""{0}"" is not an integer. Try again: ", Value);
                Value = Console.ReadLine();
            }
        }
    }

    private static void menu(string Choice)
    {
        switch (Choice.ToUpper())
        {
            case "1":
            case "R":
            case "REVERSE":
                {
                    Reverse();
                    break;
                }
            case "2":
            case "A":
            case "AVARAGE":
                {
                    Avarage();
                    break;
                }
            case "3":
            case "S":
            case "SOLVE":
                {
                    LinEq();
                    break;
                }
            default:
                break;
        }
    }

    private static void LinEq()
    {
        Console.WriteLine("a*x + b = 0");
        Console.Write("Input a:");
        int a = ReadInts();
        Console.Write("Input b:");
        int b = ReadInts();
        double x = ((double)-b / (double)a);
        Console.WriteLine("x = {0}",x);
    }

    private static void Avarage()
    {
        Console.WriteLine("Size of array: ");
        int N = -1;
        while (N<1)
        {
            N = ReadInts();
        }
        int[] ArrayOfInts = new int[N];
        Console.WriteLine("Input elements:");
        int Sum = 0;
        for (int index = 0; index < N; index++)
        {
            ArrayOfInts[index] = ReadInts();
            Sum += ArrayOfInts[index];
        }
        int Av = Sum / ArrayOfInts.Length;
        Console.WriteLine("Avarage is: {0}", Av);
    }

    private static void Reverse()
    {
        Console.Write("Input a positive integer: ");
        int N = ReadInts();
        if (N < 0)
        {
            Console.WriteLine("Integer must be positive:");
            return;
        }
        PrintReversedInts(N);
    }

    static void PrintReversedInts(int N)
    {
        Console.Write("The reversed number is: ");
        while (N != 0)
        {
            Console.Write(N % 10);
            N /= 10;
        }
        Console.WriteLine();
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Choose which task do you want:");
        Console.WriteLine("1. Reverse");
        Console.WriteLine("2. Avarage");
        Console.WriteLine("3. Solve");
        string Choice = Console.ReadLine();        //input
        menu(Choice);
    }
}