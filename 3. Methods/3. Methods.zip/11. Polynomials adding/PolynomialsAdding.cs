﻿using System;
using System.Collections.Generic;

class PolynomialsAdding
{
    static List<int> ReadBytes()       //Reads integers from console.
    {
        List<int> Number = new List<int>();
        int index = 0;

        while (true)
        {
            int Integer;
            Console.Write("x^{0} * ", index);
            string Value = Console.ReadLine();
            bool Result = int.TryParse(Value, out Integer);
            if (Result == true)
            {
                Number.Add(Integer);
                index++;
            }
            else if (Value == "")
            {
                return Number;
            }
            else
            {
                Console.Write(@"""{0}"" is not an integer. Try again: ", Value);
                Value = Console.ReadLine();
            }
        }
    }

    static List<int> AddNumbers(List<int> FirstPolynom, List<int> SecondPolynom)
    {
        List<int> Sum = new List<int>();
        int lengthBig, lengthLow;
        if (FirstPolynom.Count > SecondPolynom.Count)
        {
            lengthBig = FirstPolynom.Count;
            lengthLow = SecondPolynom.Count;
            for (int index = 0; index < lengthBig; index++)
            {
                if (index < lengthLow)
                {
                    int Sume = (FirstPolynom[index] + SecondPolynom[index]);
                    Sum.Add(Sume);
                }
                if (index >= lengthLow)
                {
                    Sum.Add(FirstPolynom[index]);
                }
            }
        }
        else
        {
            lengthBig = SecondPolynom.Count;
            lengthLow = FirstPolynom.Count;
            for (int index = 0; index < lengthBig; index++)
            {
                if (index < lengthLow)
                {
                    int Sume = (FirstPolynom[index] + SecondPolynom[index]);
                    Sum.Add(Sume);
                }
                if (index >= lengthLow)
                {
                    Sum.Add(SecondPolynom[index]);
                }
            }
        }

        return Sum;
    }

    static void PrintList(List<int> Sum)
    {
        for (int index = Sum.Count - 1; index >= 0; index--)
        {
            if (index == 0)
            {
                Console.Write("{0}*x^{1} = ?", Sum[index], index);
            }
            else
            {
                Console.Write("{0}*x^{1} + ", Sum[index], index);
            }
                
        }
        Console.WriteLine();
    }

    static void Main(string[] args)
    {
        Console.WriteLine("Input is made single digit at a line. Leave empty line to go to next number.");
        Console.WriteLine("Input first polynom:");
        List<int> Polynom1 = ReadBytes();
        Console.WriteLine("Input second polynom:");
        List<int> Polynom2 = ReadBytes();
        List<int> Sum = AddNumbers(Polynom1, Polynom2);
        PrintList(Sum);
    }
}